
package GradeBud;
import java.io.*;
import java.util.Scanner;
public class GradeCalc extends javax.swing.JFrame {
    double assigGrade;
    double assigWeight;
    
    
    public GradeCalc() {
        initComponents();
    }

    public double[] getArray (double[]arr, String filename){
        try{
            Scanner scanner = new Scanner(new File(filename));
            int i = 0;
            while(scanner.hasNextDouble()){
                arr[i++] = scanner.nextDouble();
        }
      } catch (FileNotFoundException e){
    } return arr;
    }
    
    public void update (double [] arr, String filename, double cuGrade){
        try{
            FileWriter stream = new FileWriter(filename);
            BufferedWriter out = new BufferedWriter(stream);
            arr[1]= cuGrade;
            arr[2]+= assigWeight;
            out.write(arr[0] + " " + arr[1] + " " + arr[2]);
            out.close();
        } catch (IOException e){  
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        courseDropdown = new javax.swing.JComboBox<>();
        testGrade = new javax.swing.JTextField();
        testWeight = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        menuButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        goButton = new javax.swing.JButton();
        outLabel = new java.awt.Label();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        courseDropdown.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Period A", "Period B", "Period C", "Period D" }));

        jLabel1.setText("Enter test/assignement grade:");

        jLabel2.setText("Enter test/ assignement weight (%)");

        jLabel3.setText("Select Course");

        menuButton.setText("MAIN MENU");
        menuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuButtonActionPerformed(evt);
            }
        });

        exitButton.setText("EXIT");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });

        goButton.setText("GO");
        goButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                goButtonActionPerformed(evt);
            }
        });

        outLabel.setAlignment(java.awt.Label.CENTER);
        outLabel.setText(".");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(69, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(49, 49, 49)
                        .addComponent(courseDropdown, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(menuButton, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(testGrade, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(testWeight, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(1, 1, 1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(goButton)
                    .addComponent(exitButton))
                .addGap(25, 25, 25))
            .addComponent(outLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(courseDropdown, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(testGrade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(testWeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(3, 3, 3)
                .addComponent(goButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addComponent(outLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(menuButton)
                    .addComponent(exitButton))
                .addGap(20, 20, 20))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitButtonActionPerformed

    private void menuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuButtonActionPerformed
        setVisible(false);
        dispose();
        GradeBud gb= new GradeBud();
        gb.setVisible(true);
    }//GEN-LAST:event_menuButtonActionPerformed

    private void goButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_goButtonActionPerformed
        try{
            assigGrade= Double.parseDouble(testGrade.getText()); 
            assigWeight= Double.parseDouble(testWeight.getText());

            if (courseDropdown.getSelectedItem().equals("Period A")){
                double[] infoA = new double[3];
                getArray (infoA, "periodAinfo.txt");

                outLabel.setText("Your Grade is: "+String.valueOf(Grades.gradeCalc(infoA[1], infoA[2], assigGrade, assigWeight))+ " and "+ (infoA[2]+assigWeight)+"% of your grade is final.");

                update (infoA, "periodAinfo.txt",Grades.gradeCalc(infoA[1], infoA[2], assigGrade, assigWeight));
            } else if (courseDropdown.getSelectedItem().equals("Period B")){
                double[] infoB = new double[3];
                getArray (infoB, "periodBinfo.txt");

                outLabel.setText("Your Grade is: "+String.valueOf(Grades.gradeCalc(infoB[1], infoB[2], assigGrade, assigWeight))+ " and "+ (infoB[2]+assigWeight)+"% of your grade is final.");
                update (infoB, "periodBinfo.txt",Grades.gradeCalc(infoB[1], infoB[2], assigGrade, assigWeight));
            } else if (courseDropdown.getSelectedItem().equals("Period C")){
                double[] infoC = new double[3];
                getArray (infoC, "periodCinfo.txt");

                outLabel.setText("Your Grade is: "+String.valueOf(Grades.gradeCalc(infoC[1], infoC[2], assigGrade, assigWeight))+ " and "+ (infoC[2]+assigWeight)+"% of your grade is final.");
                update (infoC, "periodCinfo.txt",Grades.gradeCalc(infoC[1], infoC[2], assigGrade, assigWeight));
            } else if (courseDropdown.getSelectedItem().equals("Period D")){
                double[] infoD = new double[3];
                getArray (infoD, "periodDinfo.txt");

                outLabel.setText("Your Grade is: "+String.valueOf(Grades.gradeCalc(infoD[1], infoD[2], assigGrade, assigWeight))+ " and "+ (infoD[2]+assigWeight)+"% of your grade is final.");
                update (infoD, "periodDinfo.txt",Grades.gradeCalc(infoD[1], infoD[2], assigGrade, assigWeight));
            } else {
            }
        }catch(NumberFormatException e){
            outLabel.setText("Please fill all boxes with proper data");
        }
  

       
    }//GEN-LAST:event_goButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GradeCalc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GradeCalc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GradeCalc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GradeCalc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GradeCalc().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> courseDropdown;
    private javax.swing.JButton exitButton;
    private javax.swing.JButton goButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JButton menuButton;
    private java.awt.Label outLabel;
    private javax.swing.JTextField testGrade;
    private javax.swing.JTextField testWeight;
    // End of variables declaration//GEN-END:variables
}
